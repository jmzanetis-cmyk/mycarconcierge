/**
 * My Car Concierge - Automated Test Suite
 * Run with: node run_tests.js
 */

const { createClient } = require('@supabase/supabase-js');

// Configuration - Update these or use environment variables
const SUPABASE_URL = process.env.SUPABASE_URL || 'https://ifbyjxuaclwmadqbjcyp.supabase.co';
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlmYnlqeHVhY2x3bWFkcWJqY3lwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ5MDI0OTUsImV4cCI6MjA4MDQ3ODQ5NX0.wts2W0ICqTSCUpF9ewvEk59P2A0stvqqmP0CNsPfIt8';

// Test credentials
const TEST_MEMBER_EMAIL = 'testmember_auto@test.com';
const TEST_PROVIDER_EMAIL = 'testprovider@test.com';
const TEST_PASSWORD = 'testing';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Test results tracking
const results = {
  passed: 0,
  failed: 0,
  tests: []
};

function log(test, status, message = '') {
  const icon = status === 'PASS' ? '✅' : status === 'FAIL' ? '❌' : '⏭️';
  console.log(`${icon} ${test}: ${status} ${message}`);
  results.tests.push({ test, status, message });
  if (status === 'PASS') results.passed++;
  if (status === 'FAIL') results.failed++;
}

// ============================================
// TEST FUNCTIONS
// ============================================

async function testConnection() {
  try {
    const { data, error } = await supabase.from('profiles').select('count');
    if (error) throw error;
    log('Database Connection', 'PASS');
    return true;
  } catch (e) {
    log('Database Connection', 'FAIL', e.message);
    return false;
  }
}

async function testMemberSignup() {
  try {
    const email = `testmember_${Date.now()}@test.com`;
    const { data, error } = await supabase.auth.signUp({
      email,
      password: 'TestPassword123!',
      options: {
        data: { role: 'member', full_name: 'Auto Test Member' }
      }
    });
    if (error) throw error;
    log('Member Signup', 'PASS', `Created: ${email}`);
    return { email, userId: data.user?.id };
  } catch (e) {
    log('Member Signup', 'FAIL', e.message);
    return null;
  }
}

async function testProviderSignup() {
  try {
    const email = `testprovider_${Date.now()}@test.com`;
    const { data, error } = await supabase.auth.signUp({
      email,
      password: 'TestPassword123!',
      options: {
        data: { role: 'provider', business_name: 'Auto Test Shop' }
      }
    });
    if (error) throw error;
    log('Provider Signup', 'PASS', `Created: ${email}`);
    return { email, userId: data.user?.id };
  } catch (e) {
    log('Provider Signup', 'FAIL', e.message);
    return null;
  }
}

async function testLogin(email, password) {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    if (error) throw error;
    log('Login', 'PASS', `User: ${email}`);
    return data;
  } catch (e) {
    log('Login', 'FAIL', e.message);
    return null;
  }
}

async function testPasswordReset(email) {
  try {
    const { data, error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: 'https://www.mycarconcierge.co/reset-password.html'
    });
    if (error) throw error;
    log('Password Reset Email', 'PASS', `Sent to: ${email}`);
    return true;
  } catch (e) {
    log('Password Reset Email', 'FAIL', e.message);
    return false;
  }
}

async function testGetProfile(userId) {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();
    if (error) throw error;
    log('Get Profile', 'PASS', `Role: ${data.role}`);
    return data;
  } catch (e) {
    log('Get Profile', 'FAIL', e.message);
    return null;
  }
}

async function testAddVehicle(ownerId) {
  try {
    const { data, error } = await supabase.from('vehicles').insert({
      owner_id: ownerId,
      make: 'Honda',
      model: 'Accord',
      year: 2023,
      vin: 'TESTAUTO' + Date.now(),
      color: 'Silver',
      license_plate: 'TEST123'
    }).select();
    if (error) throw error;
    log('Add Vehicle', 'PASS', `ID: ${data[0].id}`);
    return data[0];
  } catch (e) {
    log('Add Vehicle', 'FAIL', e.message);
    return null;
  }
}

async function testGetVehicles(ownerId) {
  try {
    const { data, error } = await supabase
      .from('vehicles')
      .select('*')
      .eq('owner_id', ownerId);
    if (error) throw error;
    log('Get Vehicles', 'PASS', `Found: ${data.length} vehicles`);
    return data;
  } catch (e) {
    log('Get Vehicles', 'FAIL', e.message);
    return null;
  }
}

async function testCreateServiceRequest(memberId, vehicleId) {
  try {
    const { data, error } = await supabase.from('maintenance_packages').insert({
      member_id: memberId,
      vehicle_id: vehicleId,
      title: 'Auto Test Service Request',
      description: 'This is an automated test request for QA purposes.',
      service_type: 'maintenance',
      status: 'open',
      preferred_pickup: 'provider_handles'
    }).select();
    if (error) throw error;
    log('Create Service Request', 'PASS', `ID: ${data[0].id}`);
    return data[0];
  } catch (e) {
    log('Create Service Request', 'FAIL', e.message);
    return null;
  }
}

async function testGetOpenRequests() {
  try {
    const { data, error } = await supabase
      .from('maintenance_packages')
      .select('*, vehicles(*), profiles(*)')
      .eq('status', 'open');
    if (error) throw error;
    log('Get Open Requests', 'PASS', `Found: ${data.length} open requests`);
    return data;
  } catch (e) {
    log('Get Open Requests', 'FAIL', e.message);
    return null;
  }
}

async function testSubmitBid(providerId, requestId) {
  try {
    const { data, error } = await supabase.from('bids').insert({
      provider_id: providerId,
      request_id: requestId,
      amount: 150.00,
      estimated_hours: 2,
      description: 'Auto test bid - will complete within 24 hours',
      offers_pickup_dropoff: true,
      pickup_dropoff_fee: 25.00,
      status: 'pending'
    }).select();
    if (error) throw error;
    log('Submit Bid', 'PASS', `ID: ${data[0].id}, Amount: $${data[0].amount}`);
    return data[0];
  } catch (e) {
    log('Submit Bid', 'FAIL', e.message);
    return null;
  }
}

async function testGetBidsForRequest(requestId) {
  try {
    const { data, error } = await supabase
      .from('bids')
      .select('*, profiles(*)')
      .eq('request_id', requestId);
    if (error) throw error;
    log('Get Bids for Request', 'PASS', `Found: ${data.length} bids`);
    return data;
  } catch (e) {
    log('Get Bids for Request', 'FAIL', e.message);
    return null;
  }
}

async function testAcceptBid(requestId, bidId) {
  try {
    // Update the bid status
    const { error: bidError } = await supabase
      .from('bids')
      .update({ status: 'accepted' })
      .eq('id', bidId);
    if (bidError) throw bidError;

    // Update the request with accepted bid
    const { error: reqError } = await supabase
      .from('maintenance_packages')
      .update({ 
        status: 'in_progress',
        accepted_bid_id: bidId 
      })
      .eq('id', requestId);
    if (reqError) throw reqError;

    log('Accept Bid', 'PASS', `Bid ${bidId} accepted`);
    return true;
  } catch (e) {
    log('Accept Bid', 'FAIL', e.message);
    return false;
  }
}

async function testCreateAppointment(requestId, bidId) {
  try {
    const { data, error } = await supabase.from('appointments').insert({
      request_id: requestId,
      bid_id: bidId,
      type: 'pickup',
      method: 'provider_handles',
      location_address: '123 Test Street, Test City, TS 12345',
      member_preferred_time: new Date(Date.now() + 86400000).toISOString(), // Tomorrow
      member_time_notes: 'Anytime after 5pm works best',
      status: 'pending'
    }).select();
    if (error) throw error;
    log('Create Appointment', 'PASS', `ID: ${data[0].id}`);
    return data[0];
  } catch (e) {
    log('Create Appointment', 'FAIL', e.message);
    return null;
  }
}

async function testSendMessage(senderId, receiverId, requestId) {
  try {
    // First create or get conversation
    const { data: convData, error: convError } = await supabase
      .from('conversations')
      .insert({
        request_id: requestId,
        member_id: senderId,
        provider_id: receiverId
      })
      .select()
      .single();
    
    // If conversation exists, that's fine
    let conversationId = convData?.id;
    if (convError && convError.code !== '23505') { // Not a duplicate error
      throw convError;
    }
    
    if (!conversationId) {
      const { data: existingConv } = await supabase
        .from('conversations')
        .select('id')
        .eq('request_id', requestId)
        .single();
      conversationId = existingConv?.id;
    }

    const { data, error } = await supabase.from('messages').insert({
      conversation_id: conversationId,
      sender_id: senderId,
      content: 'This is an automated test message.'
    }).select();
    if (error) throw error;
    log('Send Message', 'PASS', `Message ID: ${data[0].id}`);
    return data[0];
  } catch (e) {
    log('Send Message', 'FAIL', e.message);
    return null;
  }
}

async function testCreateNotification(userId) {
  try {
    const { data, error } = await supabase.from('notifications').insert({
      user_id: userId,
      type: 'test',
      title: 'Test Notification',
      message: 'This is an automated test notification.',
      read: false
    }).select();
    if (error) throw error;
    log('Create Notification', 'PASS', `ID: ${data[0].id}`);
    return data[0];
  } catch (e) {
    log('Create Notification', 'FAIL', e.message);
    return null;
  }
}

async function testTableExists(tableName) {
  try {
    const { data, error } = await supabase.from(tableName).select('*').limit(1);
    if (error && error.code === '42P01') {
      log(`Table: ${tableName}`, 'FAIL', 'Table does not exist');
      return false;
    }
    if (error) throw error;
    log(`Table: ${tableName}`, 'PASS', 'Exists and accessible');
    return true;
  } catch (e) {
    log(`Table: ${tableName}`, 'FAIL', e.message);
    return false;
  }
}

// ============================================
// MAIN TEST RUNNER
// ============================================

async function runTests() {
  console.log('\n' + '='.repeat(60));
  console.log('   MY CAR CONCIERGE - AUTOMATED TEST SUITE');
  console.log('='.repeat(60) + '\n');
  console.log(`Supabase URL: ${SUPABASE_URL}`);
  console.log(`Test Time: ${new Date().toISOString()}\n`);
  console.log('-'.repeat(60));

  // 1. Connection Test
  console.log('\n📡 CONNECTION TESTS\n');
  const connected = await testConnection();
  if (!connected) {
    console.log('\n❌ Cannot proceed without database connection');
    return;
  }

  // 2. Table Structure Tests
  console.log('\n📋 DATABASE TABLE TESTS\n');
  const tables = [
    'profiles', 'vehicles', 'maintenance_packages', 'bids',
    'appointments', 'appointment_proposals', 'appointment_updates',
    'conversations', 'messages', 'notifications', 
    'provider_reviews', 'member_reviews', 'favorite_providers',
    'member_addresses', 'job_progress_updates', 'job_documents',
    'vehicle_service_history', 'payments', 'cancellations'
  ];
  for (const table of tables) {
    await testTableExists(table);
  }

  // 3. Auth Tests
  console.log('\n🔐 AUTHENTICATION TESTS\n');
  const loginResult = await testLogin(TEST_PROVIDER_EMAIL, TEST_PASSWORD);
  
  if (loginResult) {
    await testPasswordReset(TEST_PROVIDER_EMAIL);
    
    // 4. Profile Tests
    console.log('\n👤 PROFILE TESTS\n');
    await testGetProfile(loginResult.user.id);

    // 5. Vehicle Tests
    console.log('\n🚗 VEHICLE TESTS\n');
    const vehicles = await testGetVehicles(loginResult.user.id);
    let vehicle = vehicles?.[0];
    if (!vehicle) {
      vehicle = await testAddVehicle(loginResult.user.id);
    }

    // 6. Service Request Tests
    console.log('\n📝 SERVICE REQUEST TESTS\n');
    let serviceRequest;
    if (vehicle) {
      serviceRequest = await testCreateServiceRequest(loginResult.user.id, vehicle.id);
    }
    await testGetOpenRequests();

    // 7. Bid Tests
    console.log('\n💰 BID TESTS\n');
    let bid;
    if (serviceRequest) {
      bid = await testSubmitBid(loginResult.user.id, serviceRequest.id);
      await testGetBidsForRequest(serviceRequest.id);
    }

    // 8. Accept Bid & Appointment Tests
    console.log('\n📅 APPOINTMENT TESTS\n');
    if (bid && serviceRequest) {
      const accepted = await testAcceptBid(serviceRequest.id, bid.id);
      if (accepted) {
        await testCreateAppointment(serviceRequest.id, bid.id);
      }
    }

    // 9. Messaging Tests
    console.log('\n💬 MESSAGING TESTS\n');
    if (serviceRequest) {
      await testSendMessage(loginResult.user.id, loginResult.user.id, serviceRequest.id);
    }

    // 10. Notification Tests
    console.log('\n🔔 NOTIFICATION TESTS\n');
    await testCreateNotification(loginResult.user.id);

  } else {
    console.log('\n⚠️ Skipping authenticated tests - login failed');
    console.log('Creating new test accounts...\n');
    await testMemberSignup();
    await testProviderSignup();
  }

  // Summary
  console.log('\n' + '='.repeat(60));
  console.log('   TEST SUMMARY');
  console.log('='.repeat(60));
  console.log(`\n✅ Passed: ${results.passed}`);
  console.log(`❌ Failed: ${results.failed}`);
  console.log(`📊 Total:  ${results.passed + results.failed}\n`);

  if (results.failed > 0) {
    console.log('Failed Tests:');
    results.tests.filter(t => t.status === 'FAIL').forEach(t => {
      console.log(`  - ${t.test}: ${t.message}`);
    });
  }

  console.log('\n' + '='.repeat(60) + '\n');
}

// Run the tests
runTests().catch(console.error);
