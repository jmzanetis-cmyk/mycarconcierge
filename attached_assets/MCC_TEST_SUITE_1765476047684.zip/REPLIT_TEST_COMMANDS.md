# My Car Concierge - Replit Test Commands & Automation

## Quick Setup in Replit

```bash
# Install dependencies (run in Replit Shell)
npm install @supabase/supabase-js
npm install dotenv
```

## Environment Variables

Set these in Replit Secrets (lock icon in sidebar):

```
SUPABASE_URL=https://ifbyjxuaclwmadqbjcyp.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlmYnlqeHVhY2x3bWFkcWJqY3lwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ5MDI0OTUsImV4cCI6MjA4MDQ3ODQ5NX0.wts2W0ICqTSCUpF9ewvEk59P2A0stvqqmP0CNsPfIt8
SUPABASE_SERVICE_KEY=your_service_role_key_here
SITE_URL=https://www.mycarconcierge.co
```

---

## Manual Test Commands (Run in Replit Shell)

### 1. Test Supabase Connection

```bash
node -e "
const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(
  'https://ifbyjxuaclwmadqbjcyp.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlmYnlqeHVhY2x3bWFkcWJqY3lwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ5MDI0OTUsImV4cCI6MjA4MDQ3ODQ5NX0.wts2W0ICqTSCUpF9ewvEk59P2A0stvqqmP0CNsPfIt8'
);
supabase.from('profiles').select('count').then(r => console.log('Connection:', r.error ? 'FAILED - ' + r.error.message : 'SUCCESS'));
"
```

### 2. Test Member Signup

```bash
node -e "
const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(
  'https://ifbyjxuaclwmadqbjcyp.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlmYnlqeHVhY2x3bWFkcWJqY3lwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ5MDI0OTUsImV4cCI6MjA4MDQ3ODQ5NX0.wts2W0ICqTSCUpF9ewvEk59P2A0stvqqmP0CNsPfIt8'
);
(async () => {
  const email = 'testmember_' + Date.now() + '@test.com';
  const { data, error } = await supabase.auth.signUp({
    email: email,
    password: 'TestPassword123!',
    options: { data: { role: 'member', full_name: 'Test Member' } }
  });
  console.log('Member Signup:', error ? 'FAILED - ' + error.message : 'SUCCESS - ' + email);
})();
"
```

### 3. Test Provider Signup

```bash
node -e "
const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(
  'https://ifbyjxuaclwmadqbjcyp.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlmYnlqeHVhY2x3bWFkcWJqY3lwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ5MDI0OTUsImV4cCI6MjA4MDQ3ODQ5NX0.wts2W0ICqTSCUpF9ewvEk59P2A0stvqqmP0CNsPfIt8'
);
(async () => {
  const email = 'testprovider_' + Date.now() + '@test.com';
  const { data, error } = await supabase.auth.signUp({
    email: email,
    password: 'TestPassword123!',
    options: { data: { role: 'provider', business_name: 'Test Auto Shop' } }
  });
  console.log('Provider Signup:', error ? 'FAILED - ' + error.message : 'SUCCESS - ' + email);
})();
"
```

### 4. Test Login

```bash
node -e "
const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(
  'https://ifbyjxuaclwmadqbjcyp.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlmYnlqeHVhY2x3bWFkcWJqY3lwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ5MDI0OTUsImV4cCI6MjA4MDQ3ODQ5NX0.wts2W0ICqTSCUpF9ewvEk59P2A0stvqqmP0CNsPfIt8'
);
(async () => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email: 'testprovider@test.com',
    password: 'testing'
  });
  console.log('Login:', error ? 'FAILED - ' + error.message : 'SUCCESS - User ID: ' + data.user?.id);
})();
"
```

### 5. Test Password Reset

```bash
node -e "
const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(
  'https://ifbyjxuaclwmadqbjcyp.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlmYnlqeHVhY2x3bWFkcWJqY3lwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ5MDI0OTUsImV4cCI6MjA4MDQ3ODQ5NX0.wts2W0ICqTSCUpF9ewvEk59P2A0stvqqmP0CNsPfIt8'
);
(async () => {
  const { data, error } = await supabase.auth.resetPasswordForEmail(
    'testprovider@test.com',
    { redirectTo: 'https://www.mycarconcierge.co/reset-password.html' }
  );
  console.log('Password Reset Email:', error ? 'FAILED - ' + error.message : 'SUCCESS - Check inbox');
})();
"
```

### 6. Test Database Tables

```bash
node -e "
const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(
  'https://ifbyjxuaclwmadqbjcyp.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlmYnlqeHVhY2x3bWFkcWJqY3lwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ5MDI0OTUsImV4cCI6MjA4MDQ3ODQ5NX0.wts2W0ICqTSCUpF9ewvEk59P2A0stvqqmP0CNsPfIt8'
);
(async () => {
  const tables = ['profiles', 'vehicles', 'maintenance_packages', 'bids', 'appointments', 'messages', 'notifications'];
  for (const table of tables) {
    const { count, error } = await supabase.from(table).select('*', { count: 'exact', head: true });
    console.log(table + ':', error ? 'ERROR - ' + error.message : 'OK (' + count + ' rows)');
  }
})();
"
```

### 7. Test Add Vehicle (requires auth)

```bash
node -e "
const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(
  'https://ifbyjxuaclwmadqbjcyp.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlmYnlqeHVhY2x3bWFkcWJqY3lwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ5MDI0OTUsImV4cCI6MjA4MDQ3ODQ5NX0.wts2W0ICqTSCUpF9ewvEk59P2A0stvqqmP0CNsPfIt8'
);
(async () => {
  // First login
  const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
    email: 'testprovider@test.com',
    password: 'testing'
  });
  if (authError) { console.log('Login failed:', authError.message); return; }
  
  // Then add vehicle
  const { data, error } = await supabase.from('vehicles').insert({
    owner_id: authData.user.id,
    make: 'Toyota',
    model: 'Camry',
    year: 2022,
    vin: 'TEST' + Date.now()
  }).select();
  console.log('Add Vehicle:', error ? 'FAILED - ' + error.message : 'SUCCESS - ID: ' + data[0]?.id);
})();
"
```

### 8. Test Create Service Request

```bash
node -e "
const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(
  'https://ifbyjxuaclwmadqbjcyp.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlmYnlqeHVhY2x3bWFkcWJqY3lwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ5MDI0OTUsImV4cCI6MjA4MDQ3ODQ5NX0.wts2W0ICqTSCUpF9ewvEk59P2A0stvqqmP0CNsPfIt8'
);
(async () => {
  const { data: authData } = await supabase.auth.signInWithPassword({
    email: 'testprovider@test.com',
    password: 'testing'
  });
  if (!authData.user) { console.log('Login failed'); return; }
  
  // Get a vehicle first
  const { data: vehicles } = await supabase.from('vehicles').select('id').eq('owner_id', authData.user.id).limit(1);
  if (!vehicles?.length) { console.log('No vehicles found - add one first'); return; }
  
  const { data, error } = await supabase.from('maintenance_packages').insert({
    member_id: authData.user.id,
    vehicle_id: vehicles[0].id,
    title: 'Test Service Request',
    description: 'Oil change and tire rotation',
    service_type: 'maintenance',
    status: 'open'
  }).select();
  console.log('Create Request:', error ? 'FAILED - ' + error.message : 'SUCCESS - ID: ' + data[0]?.id);
})();
"
```

---

## Run Full Automated Test Suite

Save the test file (run_tests.js) and execute:

```bash
node run_tests.js
```

