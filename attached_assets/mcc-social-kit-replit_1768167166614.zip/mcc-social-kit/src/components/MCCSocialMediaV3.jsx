import React, { useMemo, useRef, useState } from "react";
import { toPng } from "html-to-image";

/**
 * MCCSocialMediaV3
 * - Vite+React ready
 * - Exports the active creative to PNG at native resolution
 * - Preview scales down responsively while keeping correct aspect ratio
 */
const MCCSocialMediaV3 = () => {
  const [activeTab, setActiveTab] = useState("instagram");
  const exportRef = useRef(null);

  const colors = useMemo(
    () => ({
      navy: "#0a1628",
      navyLight: "#132238",
      gold: "#c9a85c",
      goldLight: "#e3cc8b",
      cream: "#f5f0e8",
      white: "#ffffff",
      ink: "#0f0f0f",
      panel: "#1a1a1a",
      panel2: "#252525",
      border: "#333",
      muted: "#888",
      muted2: "#666"
    }),
    []
  );

  const tabs = useMemo(
    () => [
      { id: "instagram", label: "Instagram Post", size: { w: 1080, h: 1080 } },
      { id: "story", label: "Story/Reel", size: { w: 1080, h: 1920 } },
      { id: "facebook", label: "Facebook", size: { w: 1200, h: 630 } },
      { id: "twitter", label: "X/Twitter", size: { w: 1200, h: 675 } },
      { id: "linkedin", label: "LinkedIn", size: { w: 1200, h: 627 } }
    ],
    []
  );

  const captions = useMemo(
    () => ({
      instagram:
        "Car repairs without the guesswork. 🚗 Compare quotes from trusted local mechanics and book with confidence. Download My Car Concierge free today.\n\n#CarCare #AutoRepair #SaveMoney #MyCarConcierge",
      story:
        "Stop overpaying for repairs. Get instant quotes from verified mechanics 🔧 Link in bio!",
      facebook:
        "Looking for honest, affordable car repairs? My Car Concierge is your mechanic marketplace — compare quotes, book instantly, and save money. Download the free app today → mycarconcierge.com",
      twitter:
        "The smarter way to fix your car. Compare quotes from trusted mechanics in your area. Try it free → mycarconcierge.com",
      linkedin:
        "Excited to share My Car Concierge — a marketplace transforming how car owners find trusted service. We're bringing transparency to auto repair with verified mechanics and competitive pricing. Now available on iOS and Android. #Automotive #Startup #Innovation"
    }),
    []
  );

  const currentTab = tabs.find((t) => t.id === activeTab);

  // Preview scaling while keeping true aspect ratio
  const previewMax = 520;
  const aspect = currentTab.size.w / currentTab.size.h;
  const previewW = aspect >= 1 ? previewMax : Math.round(previewMax * aspect);
  const previewH = aspect >= 1 ? Math.round(previewMax / aspect) : previewMax;
  const scale = previewW / currentTab.size.w;

  const copyCaption = async () => {
    try {
      await navigator.clipboard.writeText(captions[activeTab] || "");
    } catch {
      alert("Copy failed. Try manually selecting the text.");
    }
  };

  const downloadPNG = async () => {
    if (!exportRef.current) return;

    // Export at 2x for crispness
    const dataUrl = await toPng(exportRef.current, {
      cacheBust: true,
      pixelRatio: 2,
      // Change to "transparent" if you want alpha
      backgroundColor: colors.navy
    });

    const a = document.createElement("a");
    a.href = dataUrl;
    a.download = `my-car-concierge-${activeTab}.png`;
    a.click();
  };

  // --- Reusable pieces ---
  const BrandMark = ({ variant = "full" }) => (
    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
      <svg width="58" height="22" viewBox="0 0 100 30" fill="none">
        <path
          d="M5 25 Q25 5 50 3 Q75 5 95 25"
          stroke={colors.gold}
          strokeWidth="3"
          fill="none"
          strokeLinecap="round"
        />
      </svg>

      {variant !== "iconOnly" && (
        <div style={{ lineHeight: 1.05 }}>
          <div style={{ color: colors.cream, fontSize: 16 }}>
            <span>My Car </span>
            <span style={{ fontWeight: 700 }}>Concierge</span>
          </div>
          <div
            style={{
              color: colors.gold,
              fontSize: 10,
              fontFamily: "'Inter', sans-serif",
              letterSpacing: 1.2,
              opacity: 0.9
            }}
          >
            AUTOMOTIVE MARKETPLACE
          </div>
        </div>
      )}
    </div>
  );

  const CTAButton = ({ text = "Try Free", icon = "arrow" }) => (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 10,
        padding: "12px 22px",
        background: colors.gold,
        borderRadius: 6,
        color: colors.navy,
        fontSize: 12,
        fontFamily: "'Inter', sans-serif",
        fontWeight: 800,
        letterSpacing: 0.3,
        boxShadow: "0 10px 30px rgba(0,0,0,0.25)"
      }}
    >
      {text}
      {icon === "arrow" ? (
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
        >
          <path d="M5 12h14M12 5l7 7-7 7" />
        </svg>
      ) : (
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
        >
          <path d="M12 5v14M5 12l7 7 7-7" />
        </svg>
      )}
    </div>
  );

  /**
   * TemplateFrame
   * - preview container: scaled down
   * - export node: native size (ref is placed on the native-size node)
   */
  const TemplateFrame = ({ width, height, children, style }) => {
    return (
      <div
        style={{
          width: previewW,
          height: previewH,
          borderRadius: 10,
          overflow: "hidden",
          boxShadow: "0 25px 80px rgba(0,0,0,0.55)",
          background: colors.navy
        }}
      >
        <div
          style={{
            width,
            height,
            transform: `scale(${scale})`,
            transformOrigin: "top left"
          }}
        >
          <div
            ref={exportRef}
            style={{
              width,
              height,
              ...style
            }}
          >
            {children}
          </div>
        </div>
      </div>
    );
  };

  // --- Templates ---

  const Instagram = () => (
    <TemplateFrame
      width={1080}
      height={1080}
      style={{
        position: "relative",
        fontFamily: "'Playfair Display', Georgia, serif",
        background: colors.navy
      }}
    >
      <svg
        style={{ position: "absolute", top: -220, left: -220, opacity: 0.08 }}
        width="1400"
        height="1400"
        viewBox="0 0 560 560"
      >
        <circle
          cx="280"
          cy="280"
          r="250"
          stroke={colors.gold}
          strokeWidth="60"
          fill="none"
        />
      </svg>

      <div
        style={{
          position: "absolute",
          inset: 0,
          background: `radial-gradient(ellipse at 70% 20%, rgba(201,168,92,0.14) 0%, transparent 52%),
                       radial-gradient(ellipse at 15% 85%, rgba(201,168,92,0.10) 0%, transparent 45%)`
        }}
      />

      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          height: 10,
          background: `linear-gradient(90deg, transparent, ${colors.gold}, transparent)`,
          opacity: 0.9
        }}
      />

      <div
        style={{
          position: "relative",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          padding: "140px 120px 110px"
        }}
      >
        <div style={{ marginBottom: "auto" }}>
          <BrandMark />
        </div>

        <div style={{ margin: "60px 0 70px" }}>
          <h1
            style={{
              color: colors.white,
              fontSize: 118,
              fontWeight: 800,
              lineHeight: 0.98,
              margin: 0,
              letterSpacing: -2
            }}
          >
            Car repairs,
            <br />
            <span style={{ color: colors.gold }}>no guesswork.</span>
          </h1>

          <p
            style={{
              marginTop: 34,
              color: colors.cream,
              opacity: 0.78,
              fontSize: 34,
              fontFamily: "'Inter', sans-serif",
              lineHeight: 1.35,
              maxWidth: 760
            }}
          >
            Compare quotes from trusted mechanics near you — and book with
            confidence.
          </p>
        </div>

        <div
          style={{
            display: "flex",
            alignItems: "flex-end",
            justifyContent: "space-between",
            gap: 40
          }}
        >
          <CTAButton text="Download Free" icon="arrow" />

          <div
            style={{
              width: 210,
              height: 210,
              borderRadius: 24,
              background: "rgba(19,34,56,0.7)",
              border: "1px solid rgba(201,168,92,0.25)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center"
            }}
          >
            <svg width="140" height="120" viewBox="0 0 100 90">
              <ellipse cx="50" cy="55" rx="40" ry="28" fill={colors.cream} />
              <ellipse cx="50" cy="50" rx="32" ry="22" fill={colors.navy} />
              <path
                d="M30 48 Q50 32 70 48"
                stroke={colors.gold}
                strokeWidth="2.5"
                fill="none"
                strokeLinecap="round"
              />
              <circle cx="28" cy="58" r="3" fill={colors.gold} />
              <rect x="20" y="75" width="60" height="12" fill={colors.cream} />
              <rect
                x="20"
                y="75"
                width="60"
                height="4"
                fill={colors.gold}
                opacity="0.3"
              />
            </svg>
          </div>
        </div>
      </div>
    </TemplateFrame>
  );

  const Story = () => (
    <TemplateFrame
      width={1080}
      height={1920}
      style={{
        position: "relative",
        background: colors.navy,
        fontFamily: "'Playfair Display', Georgia, serif"
      }}
    >
      <div
        style={{
          position: "absolute",
          top: -260,
          right: -260,
          width: 720,
          height: 720,
          borderRadius: "50%",
          background:
            "radial-gradient(circle, rgba(201,168,92,0.18) 0%, transparent 70%)"
        }}
      />

      <div
        style={{
          position: "absolute",
          left: 70,
          top: 220,
          bottom: 220,
          width: 6,
          background: `linear-gradient(180deg, transparent, ${colors.gold}, ${colors.gold}, transparent)`,
          opacity: 0.85
        }}
      />

      <div
        style={{
          position: "relative",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          padding: "220px 130px 170px 170px"
        }}
      >
        <div
          style={{
            alignSelf: "flex-start",
            padding: "18px 34px",
            background: "rgba(201,168,92,0.12)",
            border: `2px solid ${colors.gold}`,
            borderRadius: 10,
            color: colors.gold,
            fontSize: 26,
            fontFamily: "'Inter', sans-serif",
            fontWeight: 800,
            letterSpacing: 6,
            textTransform: "uppercase"
          }}
        >
          Free App
        </div>

        <div
          style={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            justifyContent: "center"
          }}
        >
          <h1
            style={{
              color: colors.white,
              fontSize: 138,
              fontWeight: 900,
              lineHeight: 0.95,
              margin: 0,
              letterSpacing: -2
            }}
          >
            Stop
            <br />
            <span style={{ color: colors.gold }}>overpaying</span>
            <br />
            for repairs.
          </h1>

          <p
            style={{
              color: colors.cream,
              fontSize: 44,
              fontFamily: "'Inter', sans-serif",
              opacity: 0.78,
              margin: "60px 0 0 0",
              lineHeight: 1.35,
              maxWidth: 720
            }}
          >
            Get instant quotes from verified local mechanics.
          </p>
        </div>

        <div
          style={{
            display: "flex",
            gap: 80,
            marginBottom: 80,
            paddingTop: 60,
            borderTop: "2px solid rgba(201,168,92,0.18)"
          }}
        >
          {[
            { value: "30%", label: "avg savings" },
            { value: "5★", label: "rated shops" }
          ].map((s) => (
            <div key={s.label}>
              <div
                style={{
                  color: colors.gold,
                  fontSize: 120,
                  fontWeight: 900,
                  fontFamily: "'Inter', sans-serif",
                  lineHeight: 1
                }}
              >
                {s.value}
              </div>
              <div
                style={{
                  color: colors.cream,
                  fontSize: 28,
                  fontFamily: "'Inter', sans-serif",
                  opacity: 0.6,
                  marginTop: 10
                }}
              >
                {s.label}
              </div>
            </div>
          ))}
        </div>

        <div style={{ display: "flex", justifyContent: "flex-start" }}>
          <CTAButton text="Get Started" icon="down" />
        </div>

        <div style={{ marginTop: 60, textAlign: "center", opacity: 0.7 }}>
          <span
            style={{
              color: colors.cream,
              fontSize: 28,
              fontFamily: "'Inter', sans-serif",
              letterSpacing: 6
            }}
          >
            MYCARCONCIERGE.COM
          </span>
        </div>
      </div>
    </TemplateFrame>
  );

  const Facebook = () => (
    <TemplateFrame
      width={1200}
      height={630}
      style={{
        position: "relative",
        background: colors.navy,
        fontFamily: "'Playfair Display', Georgia, serif"
      }}
    >
      <svg
        style={{ position: "absolute", right: -50, top: -50, opacity: 0.06 }}
        width="520"
        height="520"
        viewBox="0 0 300 300"
      >
        <circle
          cx="150"
          cy="150"
          r="100"
          stroke={colors.gold}
          strokeWidth="40"
          fill="none"
        />
        <circle
          cx="150"
          cy="150"
          r="60"
          stroke={colors.gold}
          strokeWidth="20"
          fill="none"
        />
      </svg>

      <div
        style={{
          position: "absolute",
          left: 0,
          top: 0,
          bottom: 0,
          width: 12,
          background: colors.gold
        }}
      />

      <div
        style={{
          position: "relative",
          height: "100%",
          display: "flex",
          padding: "85px 90px 95px 105px",
          gap: 80
        }}
      >
        <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
          <div style={{ marginBottom: 40 }}>
            <BrandMark />
          </div>

          <h1
            style={{
              color: colors.white,
              fontSize: 86,
              fontWeight: 900,
              lineHeight: 0.98,
              margin: "0 0 24px 0"
            }}
          >
            Your mechanic
            <br />
            <span style={{ color: colors.gold }}>marketplace.</span>
          </h1>

          <div style={{ display: "flex", gap: 40, marginTop: 12 }}>
            {["Compare quotes", "Book instantly", "Save money"].map((text) => (
              <div
                key={text}
                style={{ display: "flex", alignItems: "center", gap: 12 }}
              >
                <div
                  style={{
                    width: 34,
                    height: 34,
                    borderRadius: "50%",
                    background: colors.gold,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center"
                  }}
                >
                  <svg
                    width="18"
                    height="18"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke={colors.navy}
                    strokeWidth="3"
                  >
                    <path d="M5 12l5 5L20 7" />
                  </svg>
                </div>
                <span
                  style={{
                    color: colors.cream,
                    fontSize: 26,
                    fontFamily: "'Inter', sans-serif",
                    opacity: 0.9
                  }}
                >
                  {text}
                </span>
              </div>
            ))}
          </div>

          <div style={{ marginTop: 46 }}>
            <CTAButton text="Download Free" icon="arrow" />
          </div>
        </div>

        <div
          style={{
            width: 300,
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
          }}
        >
          <div
            style={{
              width: 240,
              height: 420,
              background: colors.navyLight,
              borderRadius: 28,
              border: "3px solid rgba(201,168,92,0.28)",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              padding: 24,
              gap: 14
            }}
          >
            <svg width="90" height="80" viewBox="0 0 100 90">
              <ellipse cx="50" cy="55" rx="35" ry="25" fill={colors.cream} />
              <ellipse
                cx="50"
                cy="52"
                rx="28"
                ry="18"
                fill={colors.navyLight}
              />
              <path
                d="M32 50 Q50 36 68 50"
                stroke={colors.gold}
                strokeWidth="2"
                fill="none"
              />
              <circle cx="28" cy="58" r="2.5" fill={colors.gold} />
            </svg>
            <div
              style={{
                color: colors.cream,
                fontSize: 22,
                fontFamily: "'Inter', sans-serif",
                textAlign: "center"
              }}
            >
              Download on
              <br />
              <span style={{ fontWeight: 900, fontSize: 28 }}>App Store</span>
            </div>
          </div>
        </div>
      </div>

      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: 12,
          right: 0,
          background: colors.gold,
          padding: "22px 90px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between"
        }}
      >
        <span
          style={{
            color: colors.navy,
            fontSize: 28,
            fontFamily: "'Inter', sans-serif",
            fontWeight: 900
          }}
        >
          Free download — start saving today
        </span>
        <span
          style={{
            color: colors.navy,
            fontSize: 24,
            fontFamily: "'Inter', sans-serif",
            opacity: 0.8
          }}
        >
          mycarconcierge.com
        </span>
      </div>
    </TemplateFrame>
  );

  const Twitter = () => (
    <TemplateFrame
      width={1200}
      height={675}
      style={{
        position: "relative",
        background: colors.navy,
        fontFamily: "'Playfair Display', Georgia, serif"
      }}
    >
      <div
        style={{
          position: "absolute",
          top: -200,
          right: 260,
          width: 520,
          height: 1100,
          background: colors.gold,
          transform: "rotate(-15deg)",
          opacity: 0.08
        }}
      />

      <div
        style={{
          position: "relative",
          height: "100%",
          display: "flex",
          alignItems: "center",
          padding: "0 110px",
          gap: 110
        }}
      >
        <div style={{ flex: 1 }}>
          <p
            style={{
              color: colors.gold,
              fontSize: 24,
              fontFamily: "'Inter', sans-serif",
              fontWeight: 800,
              letterSpacing: 6,
              textTransform: "uppercase",
              margin: "0 0 18px 0",
              opacity: 0.95
            }}
          >
            The smarter way
          </p>

          <h1
            style={{
              color: colors.white,
              fontSize: 102,
              fontWeight: 900,
              lineHeight: 0.95,
              margin: "0 0 44px 0"
            }}
          >
            to fix
            <br />
            your car.
          </h1>

          <CTAButton text="Try Free" icon="arrow" />
        </div>

        <div style={{ position: "relative", width: 360, height: 360 }}>
          <div
            style={{
              position: "absolute",
              inset: 0,
              borderRadius: "50%",
              background:
                "radial-gradient(circle, rgba(201,168,92,0.16) 0%, transparent 70%)",
              border: "2px solid rgba(201,168,92,0.20)"
            }}
          />
          <div
            style={{
              position: "absolute",
              inset: 0,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 8
            }}
          >
            <div style={{ opacity: 0.95 }}>
              <BrandMark variant="iconOnly" />
            </div>
            <span style={{ color: colors.cream, fontSize: 26, marginTop: 8 }}>
              My Car
            </span>
            <span style={{ color: colors.cream, fontSize: 36, fontWeight: 900 }}>
              Concierge
            </span>
          </div>
        </div>
      </div>
    </TemplateFrame>
  );

  const LinkedIn = () => (
    <TemplateFrame
      width={1200}
      height={627}
      style={{
        position: "relative",
        background: `linear-gradient(135deg, ${colors.navy} 0%, ${colors.navyLight} 100%)`,
        fontFamily: "'Playfair Display', Georgia, serif"
      }}
    >
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage: `linear-gradient(rgba(201,168,92,0.03) 1px, transparent 1px),
                           linear-gradient(90deg, rgba(201,168,92,0.03) 1px, transparent 1px)`,
          backgroundSize: "60px 60px"
        }}
      />

      <div
        style={{
          position: "relative",
          height: "100%",
          display: "flex",
          padding: 90,
          gap: 70
        }}
      >
        <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
          <div style={{ marginBottom: 44 }}>
            <BrandMark />
          </div>

          <h1
            style={{
              color: colors.white,
              fontSize: 72,
              fontWeight: 900,
              lineHeight: 1.05,
              margin: "0 0 22px 0",
              maxWidth: 820
            }}
          >
            Transforming how car owners find{" "}
            <span style={{ color: colors.gold }}>trusted service.</span>
          </h1>

          <p
            style={{
              color: colors.cream,
              fontSize: 30,
              fontFamily: "'Inter', sans-serif",
              opacity: 0.78,
              lineHeight: 1.4,
              margin: 0,
              maxWidth: 860
            }}
          >
            A transparent marketplace connecting vehicle owners with verified
            local mechanics.
          </p>

          <div style={{ marginTop: 44 }}>
            <CTAButton text="Learn More" icon="arrow" />
          </div>
        </div>

        <div
          style={{
            width: 360,
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            gap: 34,
            paddingLeft: 55,
            borderLeft: "2px solid rgba(201,168,92,0.18)"
          }}
        >
          {[
            { value: "30%", label: "Average Savings" },
            { value: "100%", label: "Transparent" },
            { value: "24/7", label: "Availability" }
          ].map((stat) => (
            <div key={stat.label}>
              <div
                style={{
                  color: colors.gold,
                  fontSize: 96,
                  fontWeight: 900,
                  fontFamily: "'Inter', sans-serif",
                  lineHeight: 1
                }}
              >
                {stat.value}
              </div>
              <div
                style={{
                  color: colors.cream,
                  fontSize: 24,
                  fontFamily: "'Inter', sans-serif",
                  opacity: 0.6,
                  marginTop: 8
                }}
              >
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          height: 10,
          background: `linear-gradient(90deg, ${colors.gold}, ${colors.goldLight}, ${colors.gold})`
        }}
      />
    </TemplateFrame>
  );

  const renderTemplate = () => {
    switch (activeTab) {
      case "instagram":
        return <Instagram />;
      case "story":
        return <Story />;
      case "facebook":
        return <Facebook />;
      case "twitter":
        return <Twitter />;
      case "linkedin":
        return <LinkedIn />;
      default:
        return <Instagram />;
    }
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: colors.ink,
        padding: "46px 18px",
        fontFamily: "'Inter', -apple-system, sans-serif"
      }}
    >
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700;800;900&family=Inter:wght@400;500;600;700;800;900&display=swap');`}</style>

      {/* Header */}
      <div style={{ maxWidth: 980, margin: "0 auto 26px", padding: "0 10px" }}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 14
          }}
        >
          <div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 10,
                marginBottom: 10
              }}
            >
              <div
                style={{
                  width: 8,
                  height: 8,
                  background: colors.gold,
                  borderRadius: "50%"
                }}
              />
              <span
                style={{
                  color: colors.muted2,
                  fontSize: 12,
                  letterSpacing: 2,
                  textTransform: "uppercase"
                }}
              >
                Social Media Kit
              </span>
            </div>
            <h1
              style={{
                fontSize: 34,
                fontWeight: 900,
                color: "#fff",
                margin: 0,
                fontFamily: "'Playfair Display', Georgia, serif"
              }}
            >
              My Car Concierge
            </h1>
          </div>

          <div
            style={{
              display: "flex",
              gap: 10,
              flexWrap: "wrap",
              justifyContent: "flex-end"
            }}
          >
            <button
              onClick={copyCaption}
              style={{
                padding: "10px 14px",
                borderRadius: 10,
                border: `1px solid ${colors.border}`,
                background: "transparent",
                color: "#ddd",
                fontSize: 13,
                fontWeight: 700,
                cursor: "pointer"
              }}
            >
              Copy caption
            </button>
            <button
              onClick={downloadPNG}
              style={{
                padding: "10px 14px",
                borderRadius: 10,
                border: `1px solid rgba(201,168,92,0.55)`,
                background: "rgba(201,168,92,0.12)",
                color: colors.gold,
                fontSize: 13,
                fontWeight: 900,
                cursor: "pointer"
              }}
            >
              Download PNG
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div
        style={{
          maxWidth: 980,
          margin: "0 auto 18px",
          padding: "0 10px",
          display: "flex",
          gap: 8,
          flexWrap: "wrap"
        }}
      >
        {tabs.map((tab) => {
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                padding: "10px 14px",
                borderRadius: 999,
                border: active
                  ? `1px solid ${colors.gold}`
                  : `1px solid ${colors.border}`,
                background: active ? "rgba(201,168,92,0.12)" : "transparent",
                color: active ? colors.gold : colors.muted,
                fontSize: 13,
                fontWeight: 800,
                cursor: "pointer"
              }}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Preview + Caption */}
      <div style={{ maxWidth: 980, margin: "0 auto", padding: "26px 10px" }}>
        <div
          style={{
            background: colors.panel,
            borderRadius: 18,
            padding: 26,
            border: "1px solid rgba(255,255,255,0.06)"
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 12,
              marginBottom: 18
            }}
          >
            <div
              style={{
                padding: "6px 14px",
                background: colors.panel2,
                borderRadius: 999,
                fontSize: 12,
                color: colors.muted2,
                letterSpacing: 1
              }}
            >
              {currentTab.size.w}×{currentTab.size.h}
            </div>

            <div style={{ color: colors.muted2, fontSize: 12 }}>
              Preview: {previewW}×{previewH}
            </div>
          </div>

          <div
            style={{
              display: "flex",
              justifyContent: "center",
              padding: "14px 0 24px"
            }}
          >
            {renderTemplate()}
          </div>

          <div
            style={{
              marginTop: 12,
              padding: 18,
              background: colors.panel2,
              borderRadius: 14,
              border: "1px solid rgba(255,255,255,0.06)"
            }}
          >
            <div
              style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}
            >
              <span style={{ fontSize: 16 }}>💬</span>
              <span
                style={{
                  fontSize: 12,
                  fontWeight: 900,
                  color: colors.gold,
                  letterSpacing: 1.5
                }}
              >
                SUGGESTED CAPTION
              </span>
            </div>

            <pre
              style={{
                margin: 0,
                whiteSpace: "pre-wrap",
                fontSize: 13,
                color: "#cfcfcf",
                lineHeight: 1.6,
                fontFamily: "'Inter', sans-serif"
              }}
            >
              {captions[activeTab] || ""}
            </pre>
          </div>

          <div style={{ marginTop: 12, color: colors.muted2, fontSize: 12 }}>
            Tip: If export looks blurry, increase{" "}
            <code style={{ color: "#ddd" }}>pixelRatio</code> in{" "}
            <code style={{ color: "#ddd" }}>toPng()</code>.
          </div>
        </div>
      </div>
    </div>
  );
};

export default MCCSocialMediaV3;
