import MCCSocialMediaV3 from "./components/MCCSocialMediaV3.jsx";

export default function App() {
  return <MCCSocialMediaV3 />;
}
