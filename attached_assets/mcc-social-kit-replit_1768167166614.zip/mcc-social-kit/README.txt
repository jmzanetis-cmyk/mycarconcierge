MCC Social Media Kit (Replit Scaffold)

Run locally or on Replit:
  npm install
  npm run dev

App entry: src/App.jsx
Component: src/components/MCCSocialMediaV3.jsx

Exports:
- Click "Download PNG" to export the active template at native resolution.
