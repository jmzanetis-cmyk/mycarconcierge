<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{printful}prestashop>printful_2b243f2b6ade2f0a5c708f38b45b730c'] = 'Printful: Print-on-demand dropshipping';
$_MODULE['<{printful}prestashop>printful_f60c772bfd686876a47e1cea71572753'] = 'Use Printful to design and sell your own shirts, hats, bags and more! We\'ll handle inventory, production, and shipping, so you can focus on building your store.';
