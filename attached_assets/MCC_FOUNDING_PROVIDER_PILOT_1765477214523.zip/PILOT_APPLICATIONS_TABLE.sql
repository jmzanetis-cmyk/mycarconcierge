-- =============================================
-- PILOT APPLICATIONS TABLE
-- Run this in Supabase SQL Editor to store
-- Founding Provider applications
-- =============================================

CREATE TABLE IF NOT EXISTS pilot_applications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  
  -- Business Info
  business_name TEXT NOT NULL,
  contact_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  
  -- Service Info
  services TEXT, -- general, collision, detailing, performance, specialty, multiple
  location TEXT,
  
  -- Application Details
  motivation TEXT,
  program TEXT DEFAULT 'founding_provider_pilot',
  
  -- Status Tracking
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'waitlisted')),
  reviewed_by UUID,
  reviewed_at TIMESTAMPTZ,
  notes TEXT, -- Internal notes for admin
  
  -- Conversion Tracking
  converted_to_provider BOOLEAN DEFAULT FALSE,
  provider_id UUID, -- Links to providers table if approved
  
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for faster lookups
CREATE INDEX idx_pilot_applications_status ON pilot_applications(status);
CREATE INDEX idx_pilot_applications_email ON pilot_applications(email);

-- RLS Policies
ALTER TABLE pilot_applications ENABLE ROW LEVEL SECURITY;

-- Anyone can submit an application (insert)
CREATE POLICY "Anyone can submit pilot application"
  ON pilot_applications FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Only admins can view applications
CREATE POLICY "Admins can view all applications"
  ON pilot_applications FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Only admins can update applications
CREATE POLICY "Admins can update applications"
  ON pilot_applications FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Trigger to update updated_at
CREATE OR REPLACE FUNCTION update_pilot_application_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER pilot_applications_updated_at
  BEFORE UPDATE ON pilot_applications
  FOR EACH ROW
  EXECUTE FUNCTION update_pilot_application_timestamp();

-- =============================================
-- HELPFUL QUERIES FOR ADMIN
-- =============================================

-- View all pending applications
-- SELECT * FROM pilot_applications WHERE status = 'pending' ORDER BY created_at DESC;

-- Approve an application
-- UPDATE pilot_applications 
-- SET status = 'approved', reviewed_at = NOW(), reviewed_by = auth.uid()
-- WHERE id = 'application-uuid-here';

-- Count applications by status
-- SELECT status, COUNT(*) FROM pilot_applications GROUP BY status;

-- =============================================

SELECT 'Pilot applications table created successfully!' AS status;
