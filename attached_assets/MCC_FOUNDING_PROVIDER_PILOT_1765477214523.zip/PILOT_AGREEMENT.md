# My Car Concierge
## Founding Provider Pilot Program Agreement

**Effective Date:** _______________

**Provider Business Name:** _______________

**Contact Name:** _______________

**Email:** _______________

---

## Program Overview

This Founding Provider Pilot Program Agreement ("Agreement") is between My Car Concierge ("Platform") and the undersigned automotive service provider ("Provider").

By participating in the Founding Provider Pilot Program, Provider agrees to the following terms:

---

## 1. Program Benefits

During the Pilot Period (90 days from activation), Provider will receive:

- **Zero Platform Fees**: Provider keeps 100% of all service revenue
- **Unlimited Bids**: No limit on the number of service requests Provider can bid on
- **Founding Provider Badge**: Permanent profile designation visible to all members
- **Priority Placement**: Enhanced visibility in search results and bid listings
- **Post-Pilot Discount**: 50% off standard bid pack pricing for 6 months after pilot ends

---

## 2. Provider Commitments

In exchange for the above benefits, Provider agrees to:

### a) Minimum Engagement
- Respond to a minimum of **five (5)** service requests during the Pilot Period
- Responses may include bids, questions, or declinations with reason

### b) Feedback Participation
- Complete at least **one (1)** feedback survey during the Pilot Period
- Respond to reasonable requests for platform improvement feedback

### c) Service Standards
- Maintain professional, timely communication with members
- Deliver services as described in accepted bids
- Maintain accurate business information on Provider profile

### d) Platform Guidelines
- Adhere to all My Car Concierge Terms of Service
- Not engage in fraudulent, misleading, or harmful behavior
- Not circumvent the platform to conduct off-platform transactions for jobs initiated through My Car Concierge

---

## 3. Pilot Period

- **Duration**: 90 days from the date Provider's account is activated
- **Start Date**: Begins when Provider receives confirmation email
- **End Date**: 90 days after Start Date, unless extended by mutual agreement

---

## 4. Post-Pilot Transition

At the end of the Pilot Period:

- Provider will transition to standard pricing (with 50% discount for 6 months)
- Founding Provider Badge remains permanently on Provider's profile
- All accumulated reviews and ratings carry forward
- Provider may choose to discontinue use of the platform at any time

---

## 5. Testimonial & Marketing Rights

Provider grants My Car Concierge permission to:

- Use Provider's business name and logo in marketing materials
- Reference Provider as a "Founding Provider" in promotional content
- Share anonymized, aggregated data about Provider's platform activity

Provider may request removal of specific marketing materials by contacting support@mycarconcierge.co.

---

## 6. Termination

Either party may terminate this Agreement at any time with written notice.

**Grounds for immediate termination by Platform:**
- Violation of Terms of Service
- Fraudulent activity
- Consistently poor service resulting in member complaints
- Failure to meet minimum engagement requirements without reasonable explanation

---

## 7. Limitation of Liability

My Car Concierge is a marketplace platform only. We do not guarantee:
- Minimum number of service requests
- Minimum revenue or income
- Member satisfaction with Provider services

Provider is solely responsible for the quality and completion of services rendered.

---

## 8. Agreement

By signing below, Provider acknowledges they have read, understood, and agree to the terms of this Founding Provider Pilot Program Agreement.

**Provider Signature:** _______________

**Printed Name:** _______________

**Date:** _______________

---

**For My Car Concierge:**

**Signature:** _______________

**Printed Name:** _______________

**Title:** _______________

**Date:** _______________

---

*Questions? Contact us at support@mycarconcierge.co*

---

© 2025 My Car Concierge. All rights reserved.
