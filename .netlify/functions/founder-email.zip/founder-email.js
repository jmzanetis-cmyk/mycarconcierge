const { Resend } = require('resend');

exports.handler = async (event, context) => {
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    const { email, name, referralCode } = JSON.parse(event.body);

    if (!email || !name || !referralCode) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Missing required fields: email, name, referralCode' })
      };
    }

    const resendApiKey = process.env.RESEND_API_KEY;
    if (!resendApiKey) {
      console.error('RESEND_API_KEY not configured');
      return {
        statusCode: 500,
        body: JSON.stringify({ error: 'Email service not configured' })
      };
    }

    const resend = new Resend(resendApiKey);

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      </head>
      <body style="margin: 0; padding: 0; background-color: #1a1a2e; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;">
        <div style="max-width: 600px; margin: 0 auto; padding: 40px 20px;">
          <div style="background: linear-gradient(135deg, #1e1e3f 0%, #2a2a4a 100%); border-radius: 16px; padding: 40px; border: 1px solid rgba(212, 168, 85, 0.3);">
            <div style="text-align: center; margin-bottom: 30px;">
              <h1 style="color: #d4a855; margin: 0; font-size: 28px;">Welcome to the Founding Member Program!</h1>
            </div>
            
            <p style="color: #e0e0e0; font-size: 16px; line-height: 1.6;">
              Dear ${name},
            </p>
            
            <p style="color: #e0e0e0; font-size: 16px; line-height: 1.6;">
              Congratulations! Your application to become a <strong style="color: #d4a855;">Founding Member</strong> of My Car Concierge has been approved!
            </p>

            <div style="background: rgba(212, 168, 85, 0.1); border: 2px solid #d4a855; border-radius: 12px; padding: 24px; margin: 24px 0; text-align: center;">
              <p style="color: #a0a0a0; margin: 0 0 8px 0; font-size: 14px;">Your Unique Referral Code</p>
              <p style="color: #d4a855; font-size: 32px; font-weight: bold; margin: 0; letter-spacing: 2px;">${referralCode}</p>
            </div>

            <h2 style="color: #4a90d9; font-size: 20px; margin-top: 30px;">How It Works</h2>
            
            <div style="background: rgba(74, 144, 217, 0.1); border-radius: 8px; padding: 16px; margin: 16px 0;">
              <p style="color: #e0e0e0; margin: 0; font-size: 15px;">
                <strong style="color: #4a90d9;">1.</strong> Share your referral code with automotive service providers<br><br>
                <strong style="color: #4a90d9;">2.</strong> When they sign up and purchase bid packs, you earn <strong style="color: #d4a855;">50% commission</strong><br><br>
                <strong style="color: #4a90d9;">3.</strong> Commissions are paid out monthly via your chosen payout method
              </p>
            </div>

            <h2 style="color: #4a90d9; font-size: 20px; margin-top: 30px;">Your QR Code</h2>
            <p style="color: #e0e0e0; font-size: 15px; line-height: 1.6;">
              Visit your <strong>Founder Dashboard</strong> to find your personalized QR code. Share it at car shows, meetups, or with local service providers for easy sign-ups!
            </p>

            <h2 style="color: #4a90d9; font-size: 20px; margin-top: 30px;">Set Up Your Payouts</h2>
            <p style="color: #e0e0e0; font-size: 15px; line-height: 1.6;">
              Don't forget to set up your payout method in the Founder Dashboard. We recommend <strong style="color: #d4a855;">Stripe Connect</strong> for instant payouts directly to your bank account.
            </p>

            <div style="text-align: center; margin-top: 32px;">
              <a href="https://mycarconcierge.co/founder-dashboard.html" style="display: inline-block; background: linear-gradient(135deg, #d4a855 0%, #b8923d 100%); color: #1a1a2e; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-weight: 600; font-size: 16px;">
                Go to Founder Dashboard
              </a>
            </div>

            <hr style="border: none; border-top: 1px solid rgba(255,255,255,0.1); margin: 32px 0;">
            
            <p style="color: #808080; font-size: 13px; text-align: center; margin: 0;">
              Thank you for being part of our founding team!<br>
              <strong style="color: #d4a855;">My Car Concierge</strong>
            </p>
          </div>
        </div>
      </body>
      </html>
    `;

    const { data, error } = await resend.emails.send({
      from: 'My Car Concierge <noreply@mycarconcierge.co>',
      to: email,
      subject: 'Welcome to the Founding Member Program!',
      html: htmlContent
    });

    if (error) {
      console.error('Resend error:', error);
      return {
        statusCode: 500,
        body: JSON.stringify({ success: false, error: error.message })
      };
    }

    console.log('Email sent successfully:', data);
    return {
      statusCode: 200,
      body: JSON.stringify({ success: true, messageId: data?.id })
    };

  } catch (err) {
    console.error('Error sending founder email:', err);
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, error: err.message })
    };
  }
};
