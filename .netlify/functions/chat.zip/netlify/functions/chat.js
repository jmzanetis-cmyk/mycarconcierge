const OpenAI = require('openai');

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY || process.env.OPENAI_API_KEY
});

const SYSTEM_PROMPT = `You are a helpful automotive concierge assistant for My Car Concierge, a platform connecting vehicle owners with service providers. You help with:
- Platform guidance and how-to questions
- General car maintenance advice
- Service request help
- Provider selection tips

Keep responses concise and helpful. If asked about specific pricing or account details, direct users to contact support.`;

const ALLOWED_ROLES = ['user', 'assistant'];

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const { messages } = JSON.parse(event.body);

    if (!messages || !Array.isArray(messages)) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'Messages array required' }) };
    }

    const sanitizedMessages = messages
      .filter(m => m && typeof m.content === 'string' && ALLOWED_ROLES.includes(m.role))
      .slice(-10)
      .map(m => ({
        role: m.role,
        content: m.content.slice(0, 2000)
      }));

    if (sanitizedMessages.length === 0) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'No valid messages provided' }) };
    }

    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        ...sanitizedMessages
      ],
      max_tokens: 500,
      temperature: 0.7
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        message: response.choices[0]?.message?.content || 'I apologize, I could not generate a response.'
      })
    };
  } catch (error) {
    console.error('Chat API error:', error.message);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Failed to process request' })
    };
  }
};
