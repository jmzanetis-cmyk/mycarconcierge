# My Car Concierge - PWA & Native Apps

## Overview
My Car Concierge (MCC) is an automotive service marketplace connecting vehicle owners (members) with service providers. The application is built as a Progressive Web App (PWA) with native app support for iOS, Android, Windows, Mac, and Linux.

## Tech Stack
- **Frontend**: Vanilla HTML, CSS, JavaScript
- **Backend**: Supabase (PostgreSQL + Auth + Storage)
- **Payments**: Stripe (integration configured)
- **PWA Features**: Service Worker, Web App Manifest, Offline Support
- **Mobile Apps**: Capacitor (iOS & Android)
- **Desktop Apps**: Electron (Windows, Mac, Linux)

## PWA Features
The app supports:
- **Install to Home Screen**: Users can add the app to their device's home screen
- **Offline Support**: Core pages are cached for offline access
- **App-like Experience**: Full-screen mode without browser chrome
- **Auto-updates**: Service worker handles app updates seamlessly

## Key Files

### PWA Files
- `manifest.json` - Web app manifest for installation
- `sw.js` - Service worker for offline support and caching
- `pwa-init.js` - PWA initialization and install prompt handling
- `icons/` - App icons for various sizes

### Application Files
- `index.html` - Landing page
- `login.html` - Authentication
- `signup-member.html` - Member registration
- `signup-provider.html` - Provider registration
- `members.html` - Member dashboard
- `providers.html` - Provider dashboard
- `admin.html` - Admin panel
- `fleet.html` - Fleet management
- `supabaseclient.js` - Supabase client + helper functions

### Database SQL Files
- `COMPLETE_DATABASE_SETUP.sql` - All 29 tables schema (run first)
- `RLS_POLICIES.sql` - Row-Level Security policies (212 policies for all tables)
- `SEED_DATA.sql` - Initial data including bid pack pricing tiers
- `SERVICE_SCHEDULING_SETUP.sql` - Service scheduling and coordination tables
- `RATING_SUSPENSION_SETUP.sql` - Provider rating suspension system with credit refunds

### Server
- `server.js` - Node.js static file server with API endpoints

### Helpdesk AI Bot
- `helpdesk-widget.js` - Floating chat widget powered by Anthropic Claude
- API endpoint: `POST /api/helpdesk`
- Two modes: `driver` (for members/car owners) and `provider` (for service providers)
- Integrated on: index.html (driver), members.html (driver), providers.html (provider)
- Features:
  - Car troubleshooting and maintenance guidance
  - Platform help for both members and providers
  - XSS-safe message rendering
  - Conversation history per session

### Native App Files
- `capacitor.config.json` - Capacitor configuration for mobile apps
- `android/` - Android native project (Capacitor)
- `ios/` - iOS native project (Capacitor)
- `electron/` - Desktop app (Electron)
  - `electron/main.js` - Main process entry point
  - `electron/preload.js` - Preload script for security
- `www/` - Web assets folder for native builds
- `scripts/build-www.sh` - Build script for native apps
- `NATIVE_APP_BUILD_GUIDE.md` - Complete build instructions

## Running the App
```bash
node server.js
```
Server runs on port 5000.

## User Roles
- `member` - Vehicle owners seeking services
- `provider` - Service professionals
- `pending_provider` - Awaiting admin approval
- `admin` - Platform administrators

## Dual Roles
Users can have dual roles:
- `is_also_member` - Provider who is also a member
- `is_also_provider` - Member who is also a provider

## Supabase Configuration
- **Project URL**: `https://ifbyjxuaclwmadqbjcyp.supabase.co`
- **Anon Key**: Configured in `supabaseclient.js`

## Database Setup Instructions

### Step 1: Run Table Schema
Run `COMPLETE_DATABASE_SETUP.sql` in Supabase SQL Editor to create all 29 tables:
- profiles, vehicles, maintenance_packages, bids
- notifications, messages, payments, disputes
- dispute_evidence, provider_applications, provider_documents
- provider_references, provider_external_reviews, provider_stats
- provider_reviews, upsell_requests, service_history, service_reminders
- bid_packs, bid_credit_purchases, package_photos
- support_tickets, ticket_messages, email_queue, sms_queue
- circumvention_reports, fleets, fleet_vehicles, fleet_approvals

### Step 2: Run RLS Policies
Run `RLS_POLICIES.sql` to enable Row-Level Security with 212 policies covering:
- 4 helper functions: is_admin(), is_provider(), is_member(), get_user_role()
- SELECT/INSERT/UPDATE/DELETE policies for all tables
- Role-based access control (member, provider, pending_provider, admin)
- Dual-role support

### Step 3: Run Seed Data
Run `SEED_DATA.sql` to populate initial data:
- Bid pack pricing tiers (18 tiers from Dipstick to Championship)

## Bid Pack Pricing
| Pack | Price | Bids | Per Bid |
|------|-------|------|---------|
| Dipstick | $200 | 50 | $4.00 |
| Spark Plug | $250 | 70 | $3.57 |
| Turbo | $300 | 95 | $3.16 |
| V8 | $400 | 140 | $2.86 |
| Muscle Car | $500 | 195 | $2.56 |
| Supercharger | $625 | 270 | $2.31 |
| Racing Team | $800 | 385 | $2.08 |
| Pit Crew | $1,000 | 535 | $1.87 |
| Speedway | $1,250 | 745 | $1.68 |
| Grand Prix | $1,500 | 990 | $1.51 |
| Formula One | $2,000 | 1,470 | $1.36 |
| Le Mans | $2,500 | 2,050 | $1.22 |
| Daytona | $3,000 | 2,725 | $1.10 |
| Indy 500 | $4,000 | 4,040 | $0.99 |
| Monaco | $5,000 | 5,620 | $0.89 |
| Autobahn | $6,250 | 7,800 | $0.80 |
| Nürburgring | $7,500 | 10,400 | $0.72 |
| Championship | $10,000 | 15,400 | $0.65 |

## Stripe Integration
Stripe is configured for:
- Member payments for accepted services
- Provider bid credit purchases
- Platform fee collection (MCC fee)

To complete Stripe setup:
1. Enable the Stripe integration in Replit
2. Create Supabase Edge Functions for payment processing
3. Set up webhook endpoints for payment events

## Deployment
- **Live Site**: https://mycarconcierge.com
- **Netlify Site ID**: 9d5045cd-8b8e-4949-868a-8a92fa54d2e0
- **Deploy Command**: `NETLIFY_AUTH_TOKEN=$NETLIFY_AUTH_TOKEN npx netlify deploy --prod --dir=. --site=9d5045cd-8b8e-4949-868a-8a92fa54d2e0`

## Service Scheduling & Coordination System

After a bid is accepted, members and providers can coordinate the service:

### Features
- **Service Scheduling**: Propose, confirm, or counter-propose appointment times
- **Vehicle Transfer Coordination**: Track vehicle handoff status (pickup, at provider, work in progress, returning, returned)
- **Location Sharing**: Share real-time location via Google Maps links

### Transfer Methods
- Member drop-off at provider location
- Provider pickup from member location
- Mobile service (provider comes to member)
- Towing service

### Vehicle Status Flow
1. With Member → 2. In Transit → 3. At Provider → 4. Work In Progress → 5. Work Complete → 6. Returning → 7. Returned

### Database Tables (SERVICE_SCHEDULING_SETUP.sql)
- `service_appointments` - Tracks scheduled service dates
- `vehicle_transfers` - Tracks vehicle handoff between parties
- `location_shares` - Temporary location sharing

### Supabase Functions (supabaseclient.js)
- Appointment functions: createAppointment(), getAppointment(), confirmAppointment(), proposeNewTime()
- Transfer functions: createVehicleTransfer(), getVehicleTransfer(), updateVehicleStatus()
- Location functions: shareLocation(), getActiveLocationShare()

## Provider Rating & Suspension System

### Overview
Providers are rated 1-5 stars by members after service completion. If a provider's average rating drops below 4 stars (with 3+ reviews), they are automatically suspended from bidding and their remaining bid credits are refunded.

### Suspension Rules
- **Threshold**: Average rating below 4.0 stars
- **Minimum reviews**: 3 reviews required before suspension can trigger
- **When suspended**:
  - Cannot place new bids
  - All remaining bid credits are automatically refunded
  - Provider receives notification
- **Resolution**: Admin can lift suspension via `lift_provider_suspension()` function

### Database Setup (RATING_SUSPENSION_SETUP.sql)
Run this SQL migration in Supabase SQL Editor to enable the system:

**New Columns in provider_stats**:
- `suspended` (boolean) - Whether provider is suspended
- `suspended_reason` (text) - Reason for suspension
- `suspended_at` (timestamp) - When suspension occurred
- `suspension_lifted_at` (timestamp) - When admin lifted suspension

**New Table**: `credit_refunds`
- Tracks all refunds given to suspended providers

**Database Functions**:
- `calculate_provider_rating(provider_id)` - Calculate average rating
- `check_provider_suspension(provider_id)` - Check and suspend if needed
- `is_provider_suspended(provider_id)` - Check suspension status
- `lift_provider_suspension(provider_id, admin_id)` - Admin lifts suspension
- `get_provider_reviews_summary(provider_id)` - Get review statistics

**Trigger**: `check_suspension_after_review`
- Automatically checks for suspension after every new review

### Client Functions (supabaseclient.js)
- `checkProviderSuspension(providerId)` - Trigger suspension check
- `isProviderSuspended(providerId)` - Check if provider is suspended
- `getProviderReviewsSummary(providerId)` - Get review stats
- `getProviderReviews(providerId, limit, offset)` - Get review list
- `submitProviderReview(reviewData)` - Submit a review (triggers check)
- `getProviderCreditRefunds(providerId)` - Get refund history
- `canProviderBid(providerId)` - Check if provider can place bids

### UI Components
- **providers.html**: Suspension alert banner, rating warning banner
- **members.html**: Review submission modal with star rating

## Member Cost Estimator

The Cost Estimator helps members understand fair pricing before providers bid. Located in the Members Dashboard.

### Service Categories (9 Total)
1. **Maintenance** - Oil changes, brakes, fluids, filters, belts
2. **Repairs** - Engine, transmission, AC, electrical
3. **Detailing** - Wash, wax, interior/exterior cleaning, ceramic coating
4. **Body Work** - Dents, scratches, paint, bumpers
5. **Inspection** - Pre-purchase, state, multi-point
6. **Diagnostics** - Check engine, electrical, transmission
7. **EV & Hybrid** - Battery health, charging systems, regenerative brakes
8. **Protection** - Undercoating/rustproofing, PPF, ceramic coating, window tinting, fabric/leather protection
9. **Engine & Performance** - Walnut shell blasting/carbon cleaning, intake cleaning, throttle body, ECU tuning, exhaust

### Features
- Vehicle class detection (Domestic, Asian, European, Electric) with appropriate pricing multipliers
- Regional labor rate adjustments (West +15%, Northeast +8%, Midwest -5%, South -10%)
- Tiered pricing (Basic/Standard/Premium) for applicable services
- "Why This Range?" explainer and "Ways to Save" tips
- One-click conversion to service request

## Vehicle Maintenance Schedule

Personalized maintenance intervals per vehicle based on manufacturer recommendations.

### Features
- Vehicle class detection with appropriate service intervals
- High-mileage adjustments (100K+ miles or 30% above expected = shorter intervals)
- Driving conditions modifiers (city/severe/towing/extreme climate/short trips/dusty)
- Service logging with date and mileage
- Status indicators (Overdue/Due Soon/Up to Date)
- One-click "Post Service Request" for due items

### Maintenance Items (17 Total)
Including: Oil change, tire rotation, air filters, brake fluid, transmission fluid, coolant, spark plugs, **carbon cleaning (walnut blasting)**, **fuel system cleaning**, **throttle body service**, brake pads, battery, wiper blades, alignment, belts, timing belt, multi-point inspection

### Direct Injection Detection
Carbon cleaning only appears for vehicles with direct injection (GDI) engines:
- **Auto-detection** based on make/model/year/trim (European 2006+, Ford EcoBoost, Hyundai/Kia GDI, Mazda Skyactiv, GM turbo engines, Subaru FA/FB, Honda turbo, etc.)
- **Manual override** - users can select fuel injection type when adding/editing vehicles
- **Toyota/Lexus D-4S** systems are detected as dual injection (both port and direct)
- **Electric vehicles** skip carbon cleaning entirely

## Car Care Academy (Educational System)

A comprehensive educational system to help members understand car maintenance and repairs.

### Components
- **Learn Hub** - Dedicated section with 4 categories: Maintenance 101, Understanding Repairs, Warning Signs, Money-Saving Tips
- **Automotive Glossary** - 25+ searchable automotive terms with plain-language definitions
- **Contextual Education** - "What is this?" expandable explanations on Maintenance Schedule items
- **Service Education** - "Why this matters" explanations on Cost Estimator services
- **Smart Reminders** - "Why it's due" context on maintenance reminders and recommendations
- **AI Tutor** - Car education mode for the AI assistant ("Ask our AI about cars")

### Content Structure
- `carEducation` - Articles for Learn Hub categories (6 categories, 36 total articles)
  - Maintenance 101, Understanding Repairs, Warning Signs, Money-Saving Tips
  - Rideshare & High-Mileage Drivers (6 articles)
  - Commercial & Fleet Vehicles (6 articles)
- `maintenanceEducation` - Explanations for 19 maintenance items (whatIsIt, whyMatters, warningSignsIfSkipped, diyDifficulty, highMileageNote)
- `serviceEducation` - Explanations for 28 Cost Estimator services
- `glossary` - 32+ automotive terms including commercial/fleet terminology

## Recent Changes
- **January 2025**:
  - Renamed "Learn" to "My Car Concierge Academy" with graduation cap icon
  - Added rideshare and commercial vehicle educational content (12 articles)
  - Made POS Integration features optional for providers (toggle in Business Profile)
  - Fixed login page mobile scrolling issue
  - Fixed "Ask our AI about cars" button functionality
  - Added Car Care Academy educational system (Learn Hub, Glossary, AI Tutor)
  - Added Protection & Prevention category to Cost Estimator (undercoating, PPF, ceramic, tinting)
  - Added Engine & Performance category (walnut blasting, carbon cleaning, ECU tuning)
  - Added direct injection detection for carbon cleaning maintenance filtering
  - Updated maintenance schedule with carbon cleaning for direct injection engines
  - Migrated domain from mycarconcierge.co to mycarconcierge.com
- **December 2024**: 
  - Converted website to PWA with manifest.json and service worker
  - Created app icons from logo
  - Added PWA meta tags to all HTML pages
  - Created install prompt banner
  - Connected to Netlify for deployment
  - Set up complete database schema (29 tables) in Supabase
  - Created RLS_POLICIES.sql with 212 security policies
  - Created SEED_DATA.sql with bid pack pricing tiers
  - Configured Stripe integration for payments
  - Added Capacitor for mobile app builds (iOS/Android)
  - Added Electron for desktop app builds (Windows/Mac/Linux)
  - Created NATIVE_APP_BUILD_GUIDE.md with complete build instructions
  - Added service scheduling and coordination system (scheduling, vehicle transfer tracking, location sharing)
  - Created SERVICE_SCHEDULING_SETUP.sql with 3 new tables
  - Added logistics dashboard to members.html and providers.html
  - Added provider rating and suspension system with automatic refunds
  - Created RATING_SUSPENSION_SETUP.sql for database migration

## User Preferences
- Dark theme UI with gold and blue accents
- Premium, luxury aesthetic

## Next Steps
1. Run RATING_SUSPENSION_SETUP.sql in Supabase SQL Editor
2. Test provider rating and suspension flow
3. Create Supabase Edge Functions for Stripe payment processing
4. Test end-to-end payment flow
5. Deploy to production
